
from playwright.sync_api import sync_playwright

def check(url, keywords):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=60000)

        links = page.query_selector_all("a[href*='/product/']")
        for link in links:
            title = link.inner_text().lower()
            if any(k in title for k in keywords):
                href = link.get_attribute("href")
                if href:
                    page.goto("https://www.pokemoncenter.com" + href)
                    if page.is_visible("text=Add to Cart"):
                        browser.close()
                        return page.url
        browser.close()
        return None
