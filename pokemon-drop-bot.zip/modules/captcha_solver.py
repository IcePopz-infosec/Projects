
import requests
import time

API_KEY = "YOUR_2CAPTCHA_API_KEY"

def solve_recaptcha(site_key, page_url):
    data = {
        'key': API_KEY,
        'method': 'userrecaptcha',
        'googlekey': site_key,
        'pageurl': page_url,
        'json': 1
    }
    resp = requests.post("http://2captcha.com/in.php", data=data)
    if resp.status_code != 200:
        print("Error sending CAPTCHA request.")
        return None

    request_id = resp.json().get("request")
    fetch_url = f"http://2captcha.com/res.php?key={API_KEY}&action=get&id={request_id}&json=1"

    for _ in range(20):  # Wait up to 100 seconds
        time.sleep(5)
        result = requests.get(fetch_url)
        if result.json().get("status") == 1:
            print("✅ CAPTCHA solved.")
            return result.json().get("request")
        elif result.json().get("request") != "CAPCHA_NOT_READY":
            print("❌ CAPTCHA error:", result.json().get("request"))
            break

    print("❌ CAPTCHA solve timed out.")
    return None

def auto_detect_and_solve(page):
    try:
        # Find the reCAPTCHA iframe and extract the sitekey
        frame = page.query_selector("iframe[src*='recaptcha']")
        if not frame:
            print("🔍 No CAPTCHA iframe found.")
            return None

        src = frame.get_attribute("src")
        if "k=" in src:
            site_key = src.split("k=")[1].split("&")[0]
            return solve_recaptcha(site_key, page.url)
        else:
            print("⚠️ CAPTCHA iframe found but no sitekey.")
            return None
    except Exception as e:
        print(f"⚠️ CAPTCHA detection failed: {e}")
        return None
